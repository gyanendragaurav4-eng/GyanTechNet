import { useState, useRef, useEffect } from "react";
import { FiTerminal, FiTrash2, FiCopy, FiChevronRight, FiWifi, FiShield, FiUsers, FiKey } from "react-icons/fi";
import { cn } from "@/lib/utils";
import { useAuth, getUsersDB, saveUsersDB, UserRecord, UserPlan } from "@/contexts/AuthContext";
import { useLocation } from "wouter";

type LogEntry = { type: "input"|"output"|"error"|"info"|"warn"|"success"; text: string; time: string };

const getTime = () => new Date().toLocaleTimeString("en-US", {hour12:false});

const PLANS: UserPlan[] = ["Free","Pro","Business","Enterprise"];

function buildCommands(): Record<string, (args: string[]) => string | string[]> {
  return {
    help: () => [
      "╔══════════════════════════════════════════════════╗",
      "║       GyanTechNet Developer Console v2.0         ║",
      "╚══════════════════════════════════════════════════╝",
      "",
      "SYSTEM COMMANDS:",
      "  help                    Show this help",
      "  clear                   Clear console",
      "  version                 Platform version info",
      "  whoami                  Current session info",
      "  date                    Current timestamp",
      "  uptime                  System uptime",
      "  echo <text>             Echo text",
      "  ping <host>             Ping a host",
      "  ls                      List workspace apps",
      "  status                  System status",
      "  api                     API endpoint docs",
      "  env                     Environment variables",
      "  test <route>            Test an API route",
      "  history                 Command history",
      "  cat <file>              Show file contents",
      "",
      "USER MANAGEMENT (Dev-Only):",
      "  user:list               List all registered users",
      "  user:create <email> <password> [name]",
      "                          Create a new user account",
      "  user:info <email>       Show user details",
      "  user:plan <email> <plan>",
      "                          Set subscription plan",
      "                          Plans: Free | Pro | Business | Enterprise",
      "  user:ban <email>        Ban a user account",
      "  user:unban <email>      Unban a user account",
      "  user:delete <email>     Delete a user account",
      "  user:count              Total registered users",
      "  user:reset <email> <newpassword>",
      "                          Reset user password",
    ],

    version: () => [
      "GyanTechNet v2.0.0",
      "Node.js v24.0.0  •  TypeScript 5.9  •  React 19",
      "Vite 6.3  •  Tailwind CSS v4  •  Express 5",
      "Build: gyantechnet-2026-10 (prod)",
    ],

    whoami: () => {
      const stored = localStorage.getItem("auth_user");
      try {
        const u = stored ? JSON.parse(stored) : null;
        if (!u) return "Not logged in.";
        return [
          `Name  : ${u.name}`,
          `Email : ${u.email}`,
          `Role  : ${u.role}`,
          `Plan  : ${u.plan}`,
          `Session: Active (localStorage)`,
        ];
      } catch { return "Session corrupted."; }
    },

    date:   () => new Date().toUTCString(),
    uptime: () => "System uptime: 14d 7h 42m 18s",
    echo:   (args) => args.join(" ") || "(empty)",

    ping: (args) => [
      `PING ${args[0]||"gyantechnet.com"} (104.21.42.153)`,
      `64 bytes from 104.21.42.153: icmp_seq=1 ttl=55 time=${(Math.random()*40+5).toFixed(1)}ms`,
      `64 bytes from 104.21.42.153: icmp_seq=2 ttl=55 time=${(Math.random()*40+5).toFixed(1)}ms`,
      `3 packets transmitted, 3 received, 0% packet loss`,
    ],

    ls: () => [
      "workspace/",
      "├── ai/        chat  image-ai  video-ai  music-ai  tts  translator  research  stories  workflows",
      "├── workspace/ notes  calendar  tasks  focus  projects  slides  sheets  whiteboard  draw",
      "├── tools/     calculator  qr-gen  weather  converter  passwords  games  cricket",
      "├── pro/       analytics  wiki  learn  meet  crm  invoices  business",
      "└── dev/       api-keys  settings  intelligence  dev-console  db-manager  api-tester",
      "",
      "50+ apps loaded ✓",
    ],

    status: () => [
      "┌─────────────────────────────────────┐",
      "│  SYSTEM STATUS                      │",
      "├─────────────────────────────────────┤",
      "│  ✓ API Server          RUNNING      │",
      "│  ✓ Auth System         OPERATIONAL  │",
      `│  ✓ User DB             ${String(getUsersDB().length + " users").padEnd(12)} │`,
      "│  ✓ Gyan AI Engine      CONFIGURED   │",
      "│  ✓ Frontend (Vite)     ACTIVE       │",
      "│  ✓ Login Persistence   ENABLED      │",
      "│  ✓ Storage             OK  (2.4 GB) │",
      "│  ✓ CDN                 ACTIVE       │",
      "└─────────────────────────────────────┘",
    ],

    api: () => [
      "GyanTechNet REST API v1",
      "",
      "POST  /api/chat             AI chat (multi-model)",
      "GET   /api/healthz          Health check",
      "POST  /api/generate-content Content generation",
      "GET   /api/weather          Weather data",
      "POST  /api/translate        Text translation",
      "GET   /api/cricket          Live cricket scores",
      "",
      "Auth: Bearer <token>  •  Rate: 1000 req/min",
    ],

    env: () => [
      "NODE_ENV=production",
      "GYAN_AI_KEY=sk-*****hidden*****",
      "SESSION_SECRET=*****hidden*****",
      "PORT=8080",
      "BASE_PATH=/api",
      "DB_URL=postgres://***@gyantechnet-db:5432/gyandb",
    ],

    test: (args) => {
      const route = args[0] || "/api/healthz";
      return [
        `Testing: GET ${route}`,
        `Status: 200 OK`,
        `Latency: ${(Math.random()*50+5).toFixed(0)}ms`,
        `Response: { "status": "ok", "version": "2.0.0" }`,
      ];
    },

    cat: (args) => {
      const file = args[0] || "";
      if (file === "package.json") return ['{ "name": "@workspace/gyantechnet", "version": "2.0.0" }'];
      if (file === "README.md") return ["# GyanTechNet","","All-in-one AI platform with 50+ workspace apps."];
      return `cat: ${file || "(no file)"}: No such file or directory`;
    },

    // ─── USER MANAGEMENT ─────────────────────────────────────────────────────

    "user:list": () => {
      const users = getUsersDB();
      if (users.length === 0) return "No users registered yet. Use user:create to add one.";
      const lines: string[] = [
        `Total: ${users.length} user(s)`,
        "",
        `${"#".padEnd(3)} ${"EMAIL".padEnd(30)} ${"NAME".padEnd(18)} ${"PLAN".padEnd(12)} ${"STATUS".padEnd(10)} CREATED`,
        "─".repeat(95),
      ];
      users.forEach((u, i) => {
        const created = new Date(u.createdAt).toLocaleDateString("en-IN");
        const status = u.banned ? "BANNED" : "Active";
        lines.push(
          `${String(i+1).padEnd(3)} ${u.email.padEnd(30)} ${u.name.slice(0,17).padEnd(18)} ${u.plan.padEnd(12)} ${status.padEnd(10)} ${created}`
        );
      });
      return lines;
    },

    "user:count": () => {
      const users = getUsersDB();
      return [
        `Total users: ${users.length}`,
        `Active: ${users.filter(u=>!u.banned).length}`,
        `Banned: ${users.filter(u=>u.banned).length}`,
        `Free: ${users.filter(u=>u.plan==="Free").length}  |  Pro: ${users.filter(u=>u.plan==="Pro").length}  |  Business: ${users.filter(u=>u.plan==="Business").length}  |  Enterprise: ${users.filter(u=>u.plan==="Enterprise").length}`,
      ];
    },

    "user:create": (args) => {
      const [email, password, ...nameParts] = args;
      if (!email) return "Usage: user:create <email> <password> [name]";
      if (!password) return "Usage: user:create <email> <password> [name]";
      if (!email.includes("@")) return `Error: invalid email address: ${email}`;
      if (password.length < 6) return "Error: password must be at least 6 characters.";
      const users = getUsersDB();
      if (users.find(u => u.email === email)) return `Error: email already registered: ${email}`;
      const name = nameParts.join(" ") || email.split("@")[0];
      const rec: UserRecord = {
        name, email, password,
        role: "user", plan: "Free",
        banned: false,
        createdAt: Date.now(), lastLogin: Date.now(),
      };
      saveUsersDB([...users, rec]);
      return [
        `✓ User created successfully`,
        `  Email   : ${email}`,
        `  Name    : ${name}`,
        `  Password: ${password}`,
        `  Plan    : Free (default)`,
        `  Role    : user`,
        ``,
        `  Tip: Use user:plan ${email} Pro  to upgrade subscription.`,
      ];
    },

    "user:info": (args) => {
      const email = args[0];
      if (!email) return "Usage: user:info <email>";
      const users = getUsersDB();
      const u = users.find(u => u.email === email);
      if (!u) return `Error: user not found: ${email}`;
      return [
        `User Info — ${email}`,
        "─".repeat(40),
        `  Name        : ${u.name}`,
        `  Email       : ${u.email}`,
        `  Role        : ${u.role}`,
        `  Plan        : ${u.plan}`,
        `  Status      : ${u.banned ? "BANNED" : "Active"}`,
        `  Created     : ${new Date(u.createdAt).toLocaleString("en-IN")}`,
        `  Last Login  : ${new Date(u.lastLogin).toLocaleString("en-IN")}`,
      ];
    },

    "user:plan": (args) => {
      const [email, plan] = args;
      if (!email || !plan) return "Usage: user:plan <email> <plan>   (Free | Pro | Business | Enterprise)";
      if (!PLANS.includes(plan as UserPlan)) return `Error: invalid plan "${plan}". Valid: Free | Pro | Business | Enterprise`;
      const users = getUsersDB();
      const idx = users.findIndex(u => u.email === email);
      if (idx === -1) return `Error: user not found: ${email}`;
      const updated = users.map((u,i) => i === idx ? { ...u, plan: plan as UserPlan } : u);
      saveUsersDB(updated);
      // Also update current session if this user is logged in
      const stored = localStorage.getItem("auth_user");
      if (stored) {
        try {
          const sess = JSON.parse(stored);
          if (sess.email === email) {
            localStorage.setItem("auth_user", JSON.stringify({ ...sess, plan }));
          }
        } catch { /* ignore */ }
      }
      return [
        `✓ Subscription updated`,
        `  Email : ${email}`,
        `  Plan  : ${users[idx].plan} → ${plan}`,
        `  Changes take effect on next login (session auto-updated if currently logged in).`,
      ];
    },

    "user:ban": (args) => {
      const email = args[0];
      if (!email) return "Usage: user:ban <email>";
      const users = getUsersDB();
      const idx = users.findIndex(u => u.email === email);
      if (idx === -1) return `Error: user not found: ${email}`;
      if (users[idx].banned) return `User ${email} is already banned.`;
      saveUsersDB(users.map((u,i) => i === idx ? { ...u, banned: true } : u));
      return `✓ User banned: ${email}  (they will be blocked on next login)`;
    },

    "user:unban": (args) => {
      const email = args[0];
      if (!email) return "Usage: user:unban <email>";
      const users = getUsersDB();
      const idx = users.findIndex(u => u.email === email);
      if (idx === -1) return `Error: user not found: ${email}`;
      if (!users[idx].banned) return `User ${email} is not banned.`;
      saveUsersDB(users.map((u,i) => i === idx ? { ...u, banned: false } : u));
      return `✓ User unbanned: ${email}  (they can now log in again)`;
    },

    "user:delete": (args) => {
      const email = args[0];
      if (!email) return "Usage: user:delete <email>";
      const users = getUsersDB();
      const idx = users.findIndex(u => u.email === email);
      if (idx === -1) return `Error: user not found: ${email}`;
      saveUsersDB(users.filter((_,i) => i !== idx));
      return `✓ User deleted: ${email}  (account permanently removed)`;
    },

    "user:reset": (args) => {
      const [email, newpass] = args;
      if (!email || !newpass) return "Usage: user:reset <email> <newpassword>";
      if (newpass.length < 6) return "Error: password must be at least 6 characters.";
      const users = getUsersDB();
      const idx = users.findIndex(u => u.email === email);
      if (idx === -1) return `Error: user not found: ${email}`;
      saveUsersDB(users.map((u,i) => i === idx ? { ...u, password: newpass } : u));
      return `✓ Password reset for: ${email}`;
    },
  };
}

export default function DevConsolePage() {
  const { isDeveloper } = useAuth();
  const [, setLocation] = useLocation();
  const [logs, setLogs] = useState<LogEntry[]>([
    { type:"info",    text:"╔═══════════════════════════════════════════════════╗", time:getTime() },
    { type:"info",    text:"║       GyanTechNet Developer Console v2.0          ║", time:getTime() },
    { type:"info",    text:"╚═══════════════════════════════════════════════════╝", time:getTime() },
    { type:"success", text:`✓ Session started: ${new Date().toLocaleString("en-IN")}`, time:getTime() },
    { type:"success", text:`✓ Login Persistence: ENABLED (localStorage)`, time:getTime() },
    { type:"info",    text:`  Users in DB: ${getUsersDB().length}`, time:getTime() },
    { type:"output",  text:'  Type "help" for all commands. Try "user:list" or "user:create".', time:getTime() },
    { type:"output",  text:"", time:getTime() },
  ]);
  const [input, setInput]     = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const [histIdx, setHistIdx] = useState(-1);
  const [connected]           = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef  = useRef<HTMLInputElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:"smooth" }); }, [logs]);

  const run = () => {
    if (!input.trim()) return;
    const cmd = input.trim();
    const newLogs: LogEntry[] = [...logs, { type:"input", text:`$ ${cmd}`, time:getTime() }];
    setHistory(prev => [cmd, ...prev.slice(0, 99)]);
    setHistIdx(-1);

    const parts = cmd.split(" ");
    const name = parts[0];
    const args = parts.slice(1);

    if (name === "clear") {
      setLogs([{ type:"info", text:'Console cleared. Type "help" for commands.', time:getTime() }]);
      setInput(""); return;
    }
    if (name === "history") {
      if (history.length === 0) newLogs.push({ type:"output", text:"No history yet.", time:getTime() });
      history.forEach((h, i) => newLogs.push({ type:"output", text:`  ${String(i+1).padStart(3,"0")}  ${h}`, time:getTime() }));
      setLogs(newLogs); setInput(""); return;
    }

    const cmds = buildCommands();
    const fn = cmds[name];
    if (fn) {
      const out = fn(args);
      const lines = Array.isArray(out) ? out : [out];
      lines.forEach(line => {
        const t: LogEntry["type"] =
          line.startsWith("✓") ? "success" :
          line.startsWith("Error:") || line.startsWith("bash:") ? "error" :
          line.startsWith("Tip:") || line.startsWith("  Tip:") ? "warn" :
          "output";
        newLogs.push({ type:t, text:line, time:getTime() });
      });
    } else {
      newLogs.push({ type:"error", text:`bash: ${name}: command not found. Try "help" for available commands.`, time:getTime() });
    }
    newLogs.push({ type:"output", text:"", time:getTime() });
    setLogs(newLogs);
    setInput("");
  };

  const allCommandNames = Object.keys(buildCommands());

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") { run(); }
    else if (e.key === "ArrowUp")   { e.preventDefault(); const i = Math.min(histIdx+1, history.length-1); setHistIdx(i); setInput(history[i]||""); }
    else if (e.key === "ArrowDown") { e.preventDefault(); const i = Math.max(histIdx-1, -1); setHistIdx(i); setInput(i===-1 ? "" : history[i]||""); }
    else if (e.key === "Tab") {
      e.preventDefault();
      const match = allCommandNames.find(c => c.startsWith(input));
      if (match) setInput(match);
    }
    else if (e.key === "l" && e.ctrlKey) { e.preventDefault(); setLogs([{ type:"info", text:"Console cleared.", time:getTime() }]); }
  };

  if (!isDeveloper) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-[#040408] text-center p-8">
        <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center mb-4">
          <FiShield className="w-8 h-8 text-red-400" />
        </div>
        <h2 className="text-white font-black text-[20px] mb-2">Access Restricted</h2>
        <p className="text-white/40 text-[13px] mb-5">Dev Console is only accessible to the platform developer.</p>
        <button onClick={() => setLocation("/chat")} className="px-5 py-2.5 bg-violet-600 hover:bg-violet-500 text-white font-bold rounded-xl text-[13px] transition-all">
          Back to App
        </button>
      </div>
    );
  }

  const userCount = getUsersDB().length;

  return (
    <div className="flex flex-col h-full bg-[#040408] font-mono overflow-hidden"
      onClick={() => inputRef.current?.focus()}>

      {/* Title bar */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/[0.06] bg-[#08081a] shrink-0">
        <div className="flex items-center gap-2.5">
          <FiTerminal className="w-4 h-4 text-primary" />
          <span className="text-white text-[13px] font-bold">Dev Console</span>
          <span className="text-white/25 text-[11px]">gyantechnet.com</span>
        </div>
        <div className="flex items-center gap-2">
          {/* User count badge */}
          <div className="flex items-center gap-1.5 text-[10.5px] px-2 py-1 rounded-full border bg-violet-500/10 text-violet-300 border-violet-500/20">
            <FiUsers className="w-2.5 h-2.5" />
            {userCount} user{userCount !== 1 ? "s" : ""}
          </div>
          {/* Login saved badge */}
          <div className="flex items-center gap-1.5 text-[10.5px] px-2 py-1 rounded-full border bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
            <FiKey className="w-2.5 h-2.5" />
            Login Saved
          </div>
          <div className={cn("flex items-center gap-1.5 text-[10.5px] px-2 py-1 rounded-full border",
            connected ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" : "bg-red-500/10 text-red-400 border-red-500/20")}>
            <FiWifi className="w-2.5 h-2.5" />
            {connected ? "Connected" : "Offline"}
          </div>
          <button onClick={() => {
            const text = logs.map(l => `${l.time}  ${l.text}`).join("\n");
            navigator.clipboard.writeText(text).catch(()=>{});
          }} className="p-1.5 text-white/25 hover:text-white transition-all" title="Copy all logs">
            <FiCopy className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => setLogs([{ type:"info", text:'Console cleared. Type "help" for commands.', time:getTime() }])}
            className="p-1.5 text-white/25 hover:text-white transition-all" title="Clear">
            <FiTrash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Quick action chips */}
      <div className="flex items-center gap-2 px-4 py-2 border-b border-white/[0.04] bg-[#06060e] shrink-0 overflow-x-auto no-scrollbar">
        <span className="text-white/20 text-[10px] shrink-0">Quick:</span>
        {["user:list","user:count","status","user:create user@example.com pass123 UserName"].map(cmd => (
          <button key={cmd}
            onClick={() => { setInput(cmd); setTimeout(() => inputRef.current?.focus(), 0); }}
            className="text-[10px] px-2 py-0.5 rounded-md border border-violet-500/20 text-violet-300/70 hover:text-violet-200 hover:border-violet-500/40 transition-all shrink-0 whitespace-nowrap">
            {cmd}
          </button>
        ))}
      </div>

      {/* Log output */}
      <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-0.5 text-[12px] leading-relaxed">
        {logs.map((log, i) => (
          <div key={i} className={cn("flex gap-3", log.text === "" ? "h-2" : "")}>
            {log.text !== "" && (
              <>
                <span className="text-white/15 shrink-0 tabular-nums select-none text-[10px] pt-0.5">{log.time}</span>
                <span className={cn("break-all",
                  log.type === "input"   ? "text-cyan-400" :
                  log.type === "error"   ? "text-red-400" :
                  log.type === "warn"    ? "text-amber-400" :
                  log.type === "success" ? "text-emerald-400" :
                  log.type === "info"    ? "text-violet-400" :
                  "text-green-300"
                )}>{log.text}</span>
              </>
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="flex items-center gap-2 px-4 py-3 border-t border-white/[0.06] bg-[#07070f] shrink-0">
        <span className="text-emerald-400 text-[13px] shrink-0">developer@gyantech</span>
        <FiChevronRight className="w-3 h-3 text-white/20 shrink-0" />
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={onKey}
          placeholder="Type a command… (Tab: autocomplete)"
          spellCheck={false}
          autoCapitalize="off"
          className="flex-1 bg-transparent text-[12px] text-white placeholder:text-white/15 focus:outline-none caret-emerald-400"
          autoFocus
        />
        <span className="text-white/10 text-[10px] shrink-0 hidden sm:block">↑/↓: history · Ctrl+L: clear</span>
      </div>
    </div>
  );
}
